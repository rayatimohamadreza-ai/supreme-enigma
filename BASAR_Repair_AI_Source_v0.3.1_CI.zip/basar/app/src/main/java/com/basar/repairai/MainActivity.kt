package com.basar.repairai

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

private data class Device(val name: String, val emoji: String, val symptomHints: String)
private data class Topic(val title: String, val summary: String, val steps: List<String>)

private val devices = listOf(
    Device("پنکه رومیزی", "🌀", "روشن نمی‌شود، کند می‌چرخد، وزوز یا لرزش دارد"),
    Device("پنکه ایستاده", "🌀", "روشن نمی‌شود، دور کم، صدای بوش یا موتور"),
    Device("مخلوط‌کن", "🥤", "روشن نمی‌شود، بوی سوختگی، تیغه گیر کرده"),
    Device("همزن", "🥣", "سرعت کم، جرقه، صدای غیرعادی"),
    Device("جاروبرقی", "🧹", "مکش کم، خاموشی، صدای موتور"),
    Device("چرخ‌گوشت", "⚙️", "موتور نمی‌چرخد، زور کم، گیرکردن"),
    Device("آبمیوه‌گیری", "🍊", "روشن نمی‌شود، لرزش، نشتی"),
    Device("اتو", "👕", "گرم نمی‌شود، قطع‌و‌وصل، نشتی آب"),
    Device("سشوار", "💨", "باد سرد، خاموشی، بوی سوختگی"),
    Device("کتری برقی", "☕", "جوش نمی‌آورد، قطع نمی‌کند"),
    Device("پلوپز", "🍚", "گرم نمی‌شود، پخت ناقص")
)

private val topics = listOf(
    Topic("ایمنی میز تعمیر", "قطع برق، تخلیه انرژی ذخیره‌شده و پیشگیری از برق‌گرفتگی", listOf("دوشاخه را جدا کن و از نبود برق اطمینان بگیر.", "خازن‌ها ممکن است پس از قطع برق شارژ بمانند؛ تخلیه باید با روش و ابزار مناسب انجام شود.", "اندازه‌گیری روی مدار برق شهر فقط برای فرد آموزش‌دیده و با تجهیزات ایمن است.")),
    Topic("مولتی‌متر: پیوستگی و مقاومت", "تست سیم، فیوز، کلید و مسیرهای قطع‌شده", listOf("مدار را کاملاً از برق جدا کن.", "برای پیوستگی یا مقاومت، مولتی‌متر را روی حالت مناسب قرار بده.", "قطعه را در صورت امکان از مدار جدا کن تا مسیرهای موازی نتیجه را منحرف نکنند.", "عدد را همراه با واحد و شرایط تست ثبت کن.")),
    Topic("دیود و پل یکسوساز", "بررسی اتصال کوتاه یا قطعی دیودها", listOf("قطعه باید بدون برق باشد و خازن‌ها ایمن‌سازی شده باشند.", "حالت تست دیود را انتخاب کن.", "در دو جهت اندازه بگیر؛ قرائت دوطرفه نزدیک صفر می‌تواند نشانه اتصال کوتاه باشد.", "برای پل یکسوساز، هر شاخه را جداگانه و با توجه به دیتاشیت بررسی کن.")),
    Topic("خازن و ESR", "ظرفیت، نشتی و مقاومت سری معادل", listOf("خازن را ایمن تخلیه و در صورت نیاز از مدار خارج کن.", "ظرفیت را با رنج و ابزار مناسب اندازه بگیر.", "ظاهر بادکرده یا نشتی نشانه خرابی محتمل است، اما ظاهر سالم سلامت را تضمین نمی‌کند.", "ESR را با ابزار مناسب و با توجه به نوع خازن تفسیر کن.")),
    Topic("ترانزیستور و MOSFET", "بررسی پایه‌ها و اتصال کوتاه احتمالی", listOf("شماره قطعه و دیتاشیت را پیدا کن؛ ترتیب پایه‌ها یکسان نیست.", "در حالت بی‌برق، اتصال بین پایه‌ها را بررسی کن.", "MOSFET ممکن است با بار گیت باقی‌مانده رفتار گمراه‌کننده نشان دهد.", "تست در مدار ممکن است تحت تأثیر قطعات موازی باشد.")),
    Topic("منبع تغذیه سوئیچینگ", "ورودی، فیوز، یکسوساز و بخش ثانویه", listOf("بازرسی چشمی و تست قطعات فقط پس از قطع برق و ایمن‌سازی انجام شود.", "فیوز سوخته را صرفاً تعویض نکن؛ علت اتصال کوتاه را پیدا کن.", "خازن اولیه می‌تواند ولتاژ خطرناک نگه دارد.", "اندازه‌گیری زنده بخش اولیه را به تکنسین آموزش‌دیده با تجهیزات مناسب بسپار.")),
    Topic("رله، فیوز، NTC و تریاک", "قطعات حفاظتی و سوئیچینگ رایج روی برد", listOf("کد و مشخصات روی قطعه را ثبت کن.", "فیوز را از نظر پیوستگی و رله را از نظر کنتاکت و بوبین بررسی کن.", "NTC و تریاک باید با توجه به مدار و دیتاشیت تست شوند.", "قطعه حفاظتی را با مقدار یا نوع متفاوت جایگزین نکن.")),
    Topic("لحیم‌سرد و ترک مسیر", "عیب‌یابی اتصالات مکانیکی و مسیرهای مسی", listOf("با نور کافی زیر ذره‌بین بررسی کن.", "به پایه‌های سنگین، کانکتورها، رله‌ها و قطعات داغ‌شونده توجه کن.", "پیوستگی مسیر را در حالت بی‌برق بررسی کن.", "از دمای مناسب و تهویه کافی هنگام لحیم‌کاری استفاده کن."))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RepairApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun RepairApp() {
    var page by remember { mutableStateOf("home") }
    var chosen by remember { mutableStateOf<Device?>(null) }
    var symptom by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<List<String>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<String>()) }
    var voiceText by remember { mutableStateOf("") }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val spoken = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) { voiceText = spoken; symptom = spoken }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF087F8C), secondary = androidx.compose.ui.graphics.Color(0xFF536878))) {
        Scaffold(topBar = { TopAppBar(title = { Text("تعمیرکار همراه", fontWeight = FontWeight.Bold) }, actions = { TextButton(onClick = { page = "history" }) { Text("سوابق") } }) }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                when (page) {
                    "home" -> {
                        Text("دستیار فارسی تعمیر لوازم برقی", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(12.dp))
                        Card(Modifier.fillMaxWidth().clickable { page = "electronics" }, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(20.dp)) { Text("🔬 تعمیر برد الکترونیکی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("قطعات، مولتی‌متر، مسیر‌یابی و دانشنامه تعمیر") } }
                        Spacer(Modifier.height(12.dp))
                        Card(Modifier.fillMaxWidth().clickable { page = "devices" }, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(20.dp)) { Text("🧰 تعمیر انواع لوازم خانگی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("انتخاب دستگاه و عیب‌یابی مرحله‌ای") } }
                        Spacer(Modifier.height(18.dp))
                        Text("ایمنی: در صورت دود، جرقه یا بوی سوختگی دستگاه را از برق جدا کن؛ بردهای برق شهر می‌توانند حتی پس از قطع برق خطرناک باشند.", color = MaterialTheme.colorScheme.error)
                    }
                    "devices" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("انتخاب دستگاه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton(onClick = { page = "home" }) { Text("خانه") } }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(devices) { d -> Card(Modifier.fillMaxWidth().clickable { chosen = d; symptom = ""; result = emptyList(); page = "diagnose" }) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(d.emoji, style = MaterialTheme.typography.headlineMedium); Spacer(Modifier.width(14.dp)); Column { Text(d.name, fontWeight = FontWeight.Bold); Text(d.symptomHints, style = MaterialTheme.typography.bodySmall) } } } } }
                    }
                    "electronics" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("دانشنامه برد", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton(onClick = { page = "home" }) { Text("خانه") } }
                        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text("جست‌وجوی قطعه یا موضوع") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(topics.filter { (it.title + it.summary).contains(search, true) }) { t -> Card(Modifier.fillMaxWidth().clickable { page = "topic:${t.title}" }) { Column(Modifier.padding(14.dp)) { Text(t.title, fontWeight = FontWeight.Bold); Text(t.summary) } } } }
                    }
                    "diagnose" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("${chosen?.emoji} ${chosen?.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton(onClick = { page = "devices" }) { Text("بازگشت") } }
                        OutlinedTextField(value = symptom, onValueChange = { symptom = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text("نشانه را بنویس یا بگو") }, placeholder = { Text("مثلاً روشن نمی‌شود یا وزوز می‌کند") })
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR"); putExtra(RecognizerIntent.EXTRA_PROMPT, "مشکل دستگاه را بگویید") }; try { voiceLauncher.launch(i) } catch (_: Exception) { voiceText = "تشخیص گفتار روی این گوشی در دسترس نیست." } }) { Text("🎙 گفتن مشکل") }
                            Button(onClick = { result = diagnose(symptom); if (chosen != null) history = listOf("${chosen!!.name}: $symptom") + history.take(49) }, enabled = symptom.isNotBlank()) { Text("شروع عیب‌یابی") }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(result) { Text(it) } }
                    }
                    "history" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("سوابق تعمیر", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton(onClick = { page = "home" }) { Text("خانه") } }
                        if (history.isEmpty()) Text("هنوز سابقه‌ای در این نشست ثبت نشده است.") else LazyColumn { items(history) { Text("• $it", Modifier.padding(vertical = 8.dp)) } }
                    }
                    else -> {
                        val title = page.removePrefix("topic:")
                        val topic = topics.firstOrNull { it.title == title }
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); TextButton(onClick = { page = "electronics" }) { Text("بازگشت") } }
                        if (topic != null) { Text(topic.summary); Spacer(Modifier.height(12.dp)); topic.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", Modifier.padding(vertical = 5.dp)) } }
                    }
                }
            }
        }
    }
}

private fun diagnose(raw: String): List<String> {
    val s = raw.lowercase()
    if (listOf("دود", "جرقه", "برق گرفتگی", "بوی سوختگی", "سوختگی").any { s.contains(it) }) return listOf("⚠ خطر: دستگاه را از برق جدا کن، باز نکن و تا بررسی ایمن استفاده نکن.")
    val out = mutableListOf<String>()
    if (listOf("روشن نمی", "روشن نمیش", "کار نمی", "خاموش").any { s.contains(it) }) out += "۱) دستگاه را از برق جدا کن؛ سیم، دوشاخه و آثار آسیب ظاهری را بررسی کن."
    if (listOf("کند", "ضعیف", "زور", "دور کم").any { s.contains(it) }) out += "۲) پس از قطع برق، گرفتگی‌های بیرونی و تهویه را بررسی کن؛ از کارکرد طولانی در حالت گیرکرده پرهیز کن."
    if (listOf("وزوز", "صدا", "لرزش", "تق تق").any { s.contains(it) }) out += "۳) دستگاه را خاموش کن؛ گیرکردن قطعات متحرک یا شل بودن بخش‌های بیرونی را بررسی کن."
    if (listOf("گرم نمی", "سرد", "حرارت").any { s.contains(it) }) out += "۴) مسیر تنظیم و علائم ظاهری را بررسی کن؛ تست المنت و مدار داخلی باید در حالت بی‌برق و با ابزار مناسب انجام شود."
    if (out.isEmpty()) out += "برای تشخیص دقیق‌تر، نشانه را مشخص کن: روشن نشدن، کندی، صدای غیرعادی، گرمایش یا نشتی."
    out += "اگر مشکل با بررسی بیرونی رفع نشد، اندازه‌گیری داخلی را فقط با قطع برق و رعایت تخلیه خازن‌ها انجام بده. اندازه‌گیری زنده برق شهر را به فرد آموزش‌دیده بسپار."
    return out
}
